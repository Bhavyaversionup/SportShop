import React,{useState,useEffect} from 'react'
import Api from '../Api/Api';

export default function Top() {
    const [uok,setuok]=useState([]);
    let getsubject=() =>
    {
      Api.fetchData('main').then((main)=>{
           console.log("review data is"+JSON.stringify(main))
           setuok([...main])
      })
    }
    useEffect(()=>{
       getsubject();
    },[])
  return (

<div className="container">
    <div className="row">
        <div className="col-md-6">
            <h3 >FEATURE 4</h3>
            <h1>Desgined with the <br/>applicant in mind.</h1>
            <small> SaaS=Flow is built for requriters and hiring mangers who<br/> care about their applicants</small>
            <p/> <b>page builder:</b><small/> stop worrying about formatting or <br/> desgin our application-builder lets you create the <br/>
                application journeys you envision.
            <small/><p/>
            <p/><b>  Give back initiative :  </b> 
            Narrow down your applications<br/> desgin
            and let the most passionate show off with pre-<br/>screening assignments.
           <p/>
            <button type="button" className="btn btn-light bg-light" >Leran more -</button>
        </div>
        <div className="col-md-6">
            {
                uok.map((item)=>(
            <img src={item.img} 
            width={400} height={300}  alt="..."   id='btn'/>
                ))
}
        </div>
    </div>
   </div>
 

  )
}
