import React from 'react'

export default function Center() {
  return (
    <div className='container-fluid'>
    <div class="row">
        <div class="col-md-6" id="low">
            <h5> FEATURE 2</h5>
            <h2>crate customer-first <br/>connections with us</h2>
        </div>
        <div class="col-md-6"id="low">
           <h5> create awsome event experiences.we're a team of <br/>experts changing the way institutional think<br/> about residential real estate as an assert class.</h5>
        </div>
    </div>




    </div>
  )
}
