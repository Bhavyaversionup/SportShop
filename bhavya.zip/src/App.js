import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Top from './Components/Pages/Show/Top';
import Center from './Components/Pages/Show/Center';
import Fotter from './Components/Pages/Show/Fotter';
import SUb from './Components/Pages/Show/SUb';

function App() {
  return (
    <div className="App">
 
 <Top />
<Center />
<Fotter />
<SUb/>
    </div>
  );
}

export default App;
